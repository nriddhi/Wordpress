<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><?php bloginfo('name') ?></title>
<link href="http://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('stylesheet_url'); ?> " rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.slidertron-1.0.js"></script>

<?php wp_head();  ?>

</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="<?php bloginfo('home') ?>">Boldness</a></h1>
				<p>Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a></p>
			</div>
		</div>
	</div>
	<!-- end #header -->
	<div id="menu">
		 <?php	
    if (function_exists('wp_nav_menu'))    	{	
     wp_nav_menu(array(
    'theme_location' => 'wpj-main-menu', 
    'menu_id' => 'nav', 
    'fallback_cb' => 'wpj_default_menu')); 
     }  else     {  wpj_default_menu();  }	
  ?>

	</div>