<?php get_header();  ?>

<div class="container">

<div class="main-area">



<?php get_template_part('left-sidebar')    ?>



<div class="main-post-area">

<?php get_template_part('post-loop')  ?>

</div>



<?php get_template_part('right-sidebar');    ?>




</div>

 
 </div>


<?php get_footer();  ?>