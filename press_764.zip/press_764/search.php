<?php get_header();  ?>

<div id="templatemo_middle_wrapper">
	<div id="templatemo_middle">
    	
        <div id="templatemo_content">
        
            
            <div class="content_box_wrapper">
            	<div class="content_box">
                
				
				<?php if(have_posts()) : ?>
				
				<h2>  Search Result for : "<?php the_search_query();   ?>"   </h2>
                
				<?php while(have_posts())  : the_post(); ?>

				
				
				
                	<div class="post_section">
            
                        <h2><a href="<?php the_permalink();  ?>"><?php  the_title();   ?>  </a></h2>
        
                      <div class="post_meta"><strong>Date:</strong> <?php the_time('M d, Y'); ?> | <strong>Author:</strong> <a href="#"><?php the_author_posts_link();?> </a> | <a href="<?php the_permalink(); ?>"><?php comments_number( 'no responses', 'one response', '% responses' ); ?></a></div>
                      <a href="<?php bloginfo('home');  ?>" target="_parent"> <?php the_post_thumbnail('post-image', array('class' => 'post-thumb')); ?> 
</a>
                        
						<?php the_content();  ?>
						
						
                      <div class="cleaner_h20"></div>
                        <div class="category"><strong>Category: </strong><a href="#"><?php the_category(', '); ?> </a></div> 
                        <div class="btn_more float_r"><a href="<?php the_permalink(); ?>">Read more</a></div>
                        <div class="cleaner"></div>
            
                    </div>
					
					
					    <?php endwhile; ?>
                        <?php else : ?>
                        <?php get_template_part('404') ?>
                        <?php endif; ?>	

                
                </div> <!-- end of content_box -->
            </div> <!-- end of content_box_wrapper -->
            
            
        
        </div> <!-- end of templatemo_content -->
            
		<?php get_sidebar(); ?>
        
        <div class="cleaner"></div>    
    </div> <!-- end of templatemo_content -->
    
    <?php get_footer();  ?>
