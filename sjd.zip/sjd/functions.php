<?php 



add_action( 'init', 'my_custom_menus' );
 
function my_custom_menus() {
    register_nav_menus(
        array(
            'main-navigation' => __( 'Main Navigation' ),
        )
    );
}

if(function_exists('register_sidebar')){
	
	register_sidebar(array('name' => 'BottomWidget' ,'description' => 'widgetable bottom bar' ,'before_title' => '<h2>' ,'after_title' => '</h2><div class="widgetbreak"></div>', 'before_widget' => '<div class="widget">' ,'after_widget' => '</div>'  ));
	
}

function dashlinex(){
	return '<div class="dashline"></div>';
}

add_shortcode( 'dashline', 'dashlinex' );



class InfoWidget extends WP_Widget
{
  function InfoWidget()
  {
    $widget_ops = array('classname' => 'InfoWidget', 'description' => 'Displays Information!' );
    $this->WP_Widget('InfoWidget', 'Display Contact Information', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
    $contactblurb = $instance['contactblurb'];
    $email = $instance['email'];
    $phone = $instance['phone'];
    $fax = $instance['fax'];

?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('contactblurb'); ?>">Contact Blurb: <textarea class="widefat" id="<?php echo $this->get_field_id('contactblurb'); ?>" name="<?php echo $this->get_field_name('contactblurb'); ?>" type="text" ><?php echo attribute_escape($contactblurb); ?> </TEXTAREA></label></p>
  <p><label for="<?php echo $this->get_field_id('email'); ?>">Email: <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo attribute_escape($email); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('phone'); ?>">Phone: <input class="widefat" id="<?php echo $this->get_field_id('phone'); ?>" name="<?php echo $this->get_field_name('phone'); ?>" type="text" value="<?php echo attribute_escape($phone); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('fax'); ?>">Fax: <input class="widefat" id="<?php echo $this->get_field_id('fax'); ?>" name="<?php echo $this->get_field_name('fax'); ?>" type="text" value="<?php echo attribute_escape($fax); ?>" /></label></p>

<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    $instance['contactblurb'] = $new_instance['contactblurb'];
    $instance['email'] = $new_instance['email'];
    $instance['phone'] = $new_instance['phone'];
    $instance['fax'] = $new_instance['fax'];

    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
    $contactblurb = empty($instance['contactblurb']) ? ' ' : apply_filters('contactblurb', $instance['contactblurb']);
     $email = empty($instance['email']) ? ' ' : apply_filters('email', $instance['email']);
     $phone = empty($instance['phone']) ? ' ' : apply_filters('phone', $instance['phone']);
     $fax = empty($instance['fax']) ? ' ' : apply_filters('fax', $instance['fax']);
 

    if (!empty($title))
      echo $before_title . $title . $after_title;;
 
    // WIDGET CODE GOES HERE
    echo wpautop($contactblurb);
	
	echo '<ul id="contactnums">';
	echo '<li id="email">'.$email.'</li>';
	echo '<li id="phone">'.$phone.'</li>';
	echo '<li id="fax">'.$fax.' (fax)</li>';
 	echo '</ul>';

    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("InfoWidget");') );


class SocialWidget extends WP_Widget
{
  function SocialWidget()
  {
    $widget_ops = array('classname' => 'SocialWidget', 'description' => 'handles the social widget on bottom bar' );
    $this->WP_Widget('SocialWidget', 'Social Widget', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
    $description = $instance['description'];	
	$facebooklink = $instance['facebooklink'];	
	$twitterlink = $instance['twitterlink'];	
	$googlepluslink = $instance['googlepluslink'];	
	$pinterestlink = $instance['pinterestlink'];	
	$instagramlink = $instance['instagramlink'];	
	$rsslink = $instance['rsslink'];	
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>

  <p><label for="<?php echo $this->get_field_id('description'); ?>">Blurb: <textarea class="widefat" id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" type="text" ><?php echo attribute_escape($description); ?> </TEXTAREA></label></p>

  <p><label for="<?php echo $this->get_field_id('facebooklink'); ?>">Facebook Link: <input class="widefat" id="<?php echo $this->get_field_id('facebooklink'); ?>" name="<?php echo $this->get_field_name('facebooklink'); ?>" type="text" value="<?php echo attribute_escape($facebooklink); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('twitterlink'); ?>">Twitter Link: <input class="widefat" id="<?php echo $this->get_field_id('twitterlink'); ?>" name="<?php echo $this->get_field_name('twitterlink'); ?>" type="text" value="<?php echo attribute_escape($twitterlink); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('googlepluslink'); ?>">Google Plus Link: <input class="widefat" id="<?php echo $this->get_field_id('googlepluslink'); ?>" name="<?php echo $this->get_field_name('googlepluslink'); ?>" type="text" value="<?php echo attribute_escape($googlepluslink); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('instagramlink'); ?>">Instagram Link: <input class="widefat" id="<?php echo $this->get_field_id('instagramlink'); ?>" name="<?php echo $this->get_field_name('instagramlink'); ?>" type="text" value="<?php echo attribute_escape($instagramlink); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('pinterestlink'); ?>">Pinterest Link: <input class="widefat" id="<?php echo $this->get_field_id('pinterestlink'); ?>" name="<?php echo $this->get_field_name('pinterestlink'); ?>" type="text" value="<?php echo attribute_escape($pinterestlink); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('rsslink'); ?>">RSS Link: <input class="widefat" id="<?php echo $this->get_field_id('rsslink'); ?>" name="<?php echo $this->get_field_name('rsslink'); ?>" type="text" value="<?php echo attribute_escape($rsslink); ?>" /></label></p>



<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    $instance['description'] = $new_instance['description'];
    $instance['facebooklink'] = $new_instance['facebooklink'];
    $instance['googlepluslink'] = $new_instance['googlepluslink'];
    $instance['instagramlink'] = $new_instance['instagramlink'];
    $instance['twitterlink'] = $new_instance['twitterlink'];
    $instance['pinterestlink'] = $new_instance['pinterestlink'];
    $instance['rsslink'] = $new_instance['rsslink'];

    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
 	$tempath = get_bloginfo('template_url');
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
    $description = empty($instance['description']) ? ' ' : apply_filters('widget_title', $instance['description']);
    $facebooklink = empty($instance['facebooklink']) ? ' ' : apply_filters('facebooklink', $instance['facebooklink']);
    $googlepluslink = empty($instance['googlepluslink']) ? ' ' : apply_filters('googlepluslink', $instance['googlepluslink']);
    $instagramlink = empty($instance['instagramlink']) ? ' ' : apply_filters('instagramlink', $instance['instagramlink']);
    $twitterlink = empty($instance['twitterlink']) ? ' ' : apply_filters('twitterlink', $instance['twitterlink']);
    $pinterestlink = empty($instance['pinterestlink']) ? ' ' : apply_filters('pinterestlink', $instance['pinterestlink']);
    $rsslink = empty($instance['rsslink']) ? ' ' : apply_filters('rsslink', $instance['rsslink']);

 
    if (!empty($title))
      echo $before_title . $title . $after_title;;
 
    // WIDGET CODE GOES HERE
    echo wpautop($description);
 
 	echo '<div id="soc_widget_img">'; 
 		echo '<a href="'.$facebooklink.'" ?><img value="01" src="'.$tempath.'/images/icons/social_01.png" colo="'.$tempath.'/images/icons/social_color_01.png"></a>';
 		echo '<a href="'.$twitterlink.'" ?><img value="02" src="'.$tempath.'/images/icons/social_02.png" ></a>';
 		echo '<a href="'.$googlepluslink.'" ?><img value="03" src="'.$tempath.'/images/icons/social_03.png" ></a>';
 		echo '<a href="'.$instagramlink.'" ?><img value="04" src="'.$tempath.'/images/icons/social_04.png" ></a>';
 		echo '<a href="'.$pinterestlink.'" ?><img value="05" src="'.$tempath.'/images/icons/social_05.png" ></a>';
 		echo '<a href="'.$rsslink.'" ?><img value="06" src="'.$tempath.'/images/icons/social_06.png" ></a>';
		
 	echo '</div>';
 
    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("SocialWidget");') );

/* GOOGLE LOCATION MAP */

class GMapWidget extends WP_Widget
{
  function GMapWidget()
  {
    $widget_ops = array('classname' => 'GMapWidget', 'description' => 'Just drop, pop in location and your good to go!' );
    $this->WP_Widget('GMapWidget', 'Google Map Widget', $widget_ops);
  }
 
  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
	$mapcode = $instance['mapcode'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
  <p><label for="<?php echo $this->get_field_id('mapcode'); ?>">Google Map Code: <textarea class="widefat" id="<?php echo $this->get_field_id('mapcode'); ?>" name="<?php echo $this->get_field_name('mapcode'); ?>"  ><?php echo attribute_escape($mapcode); ?></textarea></label></p>

<?php
  }
 
  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    $instance['mapcode'] = $new_instance['mapcode'];

    return $instance;
  }
 
  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
 
    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);
    $mapcode = empty($instance['mapcode']) ? ' ' : apply_filters('mapcode', $instance['mapcode']);
 
 
    if (!empty($title))
      echo $before_title . $title . $after_title;;
 
    // WIDGET CODE GOES HERE
    echo '<span id="mapbox">'.$mapcode.'</span>';
    echo $after_widget;
  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("GMapWidget");') );


?>