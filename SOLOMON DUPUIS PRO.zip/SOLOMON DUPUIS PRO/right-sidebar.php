<div class="right-sidebar">



<?php if ( ! dynamic_sidebar( 'social-icon' ) ) : ?>   
 
 <?php  endif; ?>




<h2> Popular Posts   </h2>

<?php if ( ! dynamic_sidebar( 'right-sidebar' ) ) : ?>   
 
 <?php  endif; ?>



</div>