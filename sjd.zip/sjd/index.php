<!DOCTYPE html>

<html lang="en">

	<head>

		<title><?php wp_title(); ?></title>

		
       <link href="<?php bloginfo('template_url')?>/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url') ?>">

		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

		

		<script>

			

			$(document).ready(function(){

				

				

				$("#mapbox iframe").attr('width','305px');

				$("#mapbox iframe").attr('height','200px');

				

				

				$("#soc_widget_img img").hover(

					function(){

						var socid = ($(this).attr('value'));

						

						$(this).attr('src','<?php bloginfo('template_url'); ?>/images/icons/social_color_'+socid+'.png');

						//alert('<?php bloginfo('template_url'); ?>/images/icons/social_color_'+socid+'.png');

					},

					

					function(){

						var socid = ($(this).attr('value'));

						

						$(this).attr('src','<?php bloginfo('template_url'); ?>/images/icons/social_'+socid+'.png');

						

	

						

					}

				

				);

				

				

				

				

			});

			

			

			

			

		</script>

		<?php if(is_page(9)){ ?>

<script type="text/javascript">

  function tabs(x)

  {

    var lis=document.getElementById("sidebarTabs").childNodes; //gets all the LI from the UL

 

    for(i=0;i<lis.length;i++)

    {

      lis[i].className=""; //removes the classname from all the LI

    }

    x.className="selected"; //the clicked tab gets the classname selected

    var res=document.getElementById("tab1Content");  //the resource for the main tabContent

    var tab=x.id;

    switch(tab) //this switch case replaces the tabContent

    {

      case "tab1":

        res.innerHTML=document.getElementById("tab1Content").innerHTML;

        break;

 

      case "tab2":

        res.innerHTML=document.getElementById("tab2Content").innerHTML;

        break;

      case "tab3":

        res.innerHTML=document.getElementById("tab3Content").innerHTML;

        break;

      default:

        res.innerHTML=document.getElementById("tab1Content").innerHTML;

        break;

 

    }

  }

 

</script>

<?php } ?>		

		<?php wp_head(); ?>

	</head>

	<body>

		<header id="header">

					<div class="wrap_in">

						<div id="logo"><a href=""><img src="<?php bloginfo('template_directory');?>/images/logo.png" alt="Sil Jeon Do Martial Arts"></a></div>

						

						<div id="trcontact">

							<p>&nbsp;</p>							

							<p>Little Ferry (201) 853-9542</p>

							<p>&nbsp;</p>

							<p>Englewood (201) 541-2414</p>

						</div>

						

					</div>			

		</header>

		

		<!-- NAVIGATION -->

		<section id="navigation">

					<div class="wrap_in">		

									

						<?php wp_nav_menu( array( 'theme_location' => 'main-navigation', 'after' => '', 'container' => 'nav', 'menu_class' => 'primary', 'fallback_cb' => '') ); ?>



						<div id="social">

							<div>

							<a title="Sil Jeon Do Facebook" href="https://www.facebook.com/siljeon.do" target="_blank"><img alt="facebook" src="<?php bloginfo('template_url'); ?>/images/icons/social_color_01.png" alt="Sil Jeon Do Facebook" /></a>

							<a title="twitter link" href=""><img alt="twitter" src="<?php bloginfo('template_url'); ?>/images/icons/social_color_02.png" /></a>

							</div>

							

							<div>

								Connect with us:								

								

							</div>

														

						</div>

			

					</div>		

		</section>

		

		<!-- BRIDGE -->

		<section id="bridge">

					<div class="wrap_in">

					

						<div id="bridgetext">

						<p class="bridge1"><?php $title = get_post_meta($post->ID,'title', true ); if(strlen($title) > 0){echo $title; } else {echo 'Real Life Situation Fighting';} ?></p>

						<p class="bridge2"><?php $subtitle = get_post_meta($post->ID,'subtitle', true ); if(strlen($subtitle) > 0){echo $subtitle; } else {echo 'Sil Jeon Do Style Mixed Martial Arts.';} ?></p>

						</div>

					</div>			

		</section>

		

		<!-- MAIN CONTENT -->

		

		<section id="content">

					<div class="wrap_inn">

						<?php if(have_posts()): while(have_posts()): the_post(); ?>

												

						

						<div class="contentbox"><?php the_content(); ?></div>



						<div class="dashline"></div>



						

						<?php endwhile; endif; ?>

			

					</div>		

			



			

			

			

		</section>

		

		<!-- FOOTERr 1 -->

		<section id="footer1">

			<div class="wrap_inn">

				<?php if(function_exists('dynamic_sidebar')){  dynamic_sidebar('BottomWidget'); } ?>

			

			</div>	

			

			

			

		</section>

		

		<!-- FOOTER INTO -->

		<footer>

			<div class="wrap_inn">

					<p>Copyright &copy;<?php echo date("Y");?> Sil Jeon Do Mixed Martial Arts at United Martial Arts. </p>

					<p>All Rights Reserved.</p> 

			

			</div>	

			

			

		</footer>

		<?php wp_footer(); ?>

		

	</body>

	

	

</html>