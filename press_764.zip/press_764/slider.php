<div class="content_box_wrapper">
                <div class="content_box">
                
                <div id="featuredslideshow">
                  <ul> 
				  
				  <?php if(!is_paged()) { ?>
				
<?php
	$args = array( 'post_type' => 'slider', 'posts_per_page' => 4 );
	$loop = new WP_Query( $args );
?>  
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

                    <li>
					
 <?php the_post_thumbnail('slider-image', array('class' => 'post-thumb')); ?> 
					
				</li> 
				
<?php endwhile; ?>
<?php wp_reset_query(); ?>
<?php } ?>		

                    
                    <!-- eccetera --> 
                </ul> 
                </div>
     			<script type="text/javascript">
					 $("div#featuredslideshow").slideViewerPro({ 
					thumbs: 4,  
					thumbsPercentReduction: 15, 
					galBorderWidth: 1, 
					galBorderColor: "#CCCCCC", 
					thumbsTopMargin: 10, 
					thumbsRightMargin: 10, 
					thumbsBorderWidth: 2, 
					thumbsActiveBorderColor: "#993399", 
					thumbsActiveBorderOpacity: 1, 
					thumbsBorderOpacity: 1, 
					buttonsTextColor: "#333333", 
				
					autoslide: true,  
					typo: true 
					});  	
				</script>
 				<!--	leftButtonInner: "<img src='images/larw.gif' alt='left' />", 
					rightButtonInner: "<img src='images/rarw.gif' alt='right' />", 	-->
                
                </div>
            </div>