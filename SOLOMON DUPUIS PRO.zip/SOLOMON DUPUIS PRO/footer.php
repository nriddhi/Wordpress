 
<div class="footer fix">



<div class="footer-menu">

<?php wp_nav_menu( array( 'theme_location' => 'menu_footer') ); ?>


</div>


</div>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script type="text/javascript">// <![CDATA[
jQuery(function(){
  var menuOffset = jQuery('.top-menu')[0].offsetTop;
  jQuery(document).bind('ready scroll',function() {
    var docScroll = jQuery(document).scrollTop();
    if(docScroll >= menuOffset) {
      jQuery('.top-menu').addClass('fixed').css('width',jQuery('#masthead').width());
    } else {
      jQuery('.top-menu').removeClass('fixed').removeAttr("width");
    }
   });
});

$(document).ready(function (){
    $('iframe').each(function(){
        var url = $(this).attr("src");
        $(this).attr("src",url+"?wmode=transparent");
    });
});

// ]]></script>


<?php wp_footer();   ?>
</body>


  
</html>
