<?php


add_action('init', 'wpj_register_menu');
	function wpj_register_menu() {
		if (function_exists('register_nav_menu')) {
			register_nav_menu( 'wpj-main-menu', __( 'Main Menu', 'brightpage' ) );
		}           }
	function wpj_default_menu() {
		echo '<ul id="nav">';
		if ('page' != get_option('show_on_front')) {
			echo '<li><a href="'. home_url() . '/">Home</a></li>';}
		wp_list_pages('title_li=');
		echo '</ul>';}     register_nav_menu( 'menu_footer', __( 'Footer Menu', 'bilanti' ) );



function solomon_widget_areas() {

		register_sidebar( array(
			'name' => __( 'Left Sidebar', 'SOLOMON' ),
			'id' => 'left-sidebar',
			'description' => __( 'Categories', 'solomon' ),
			'before_widget' => '<div class="categories-para">',
			'after_widget' => '</div>',
			'before_title' => '<h2>',
			'after_title' => '</h2>',
		) );  
	}
	
add_action('widgets_init', 'solomon_widget_areas');



function solomon_widget_areas2() {

		register_sidebar( array(
			'name' => __( 'Right Sidebar', 'Solomon' ),
			'id' => 'right-sidebar',
			'description' => __( 'Popular Post', 'solomon' ),
			'before_widget' => '<div class="popular-post-para">',
			'after_widget' => '</div>',
			'before_title' => '<h2>',
			'after_title' => '</h2>',
		) );  
	}
	
add_action('widgets_init', 'solomon_widget_areas2');



function solomon_widget_areas3() {

		register_sidebar( array(
			'name' => __( 'Social Icons', 'solomon' ),
			'id' => 'social-icon',
			'description' => __( 'Social Icons', 'solomon' ),
			'before_widget' => '<div class="social-icons"> <ul>',
			'after_widget' => '</ul> </div>',
			
		) );  
	}
	
add_action('widgets_init', 'solomon_widget_areas3');




/* Functions for Excerpt*/
function get_excerpt($count){
  $excerpt = get_the_content();
  $excerpt = strip_tags($excerpt);
  $excerpt = substr($excerpt, 0, $count);
  $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
  $excerpt = $excerpt.'[...]';
  return $excerpt;
 }


/*******************************/

add_action("widgets_init", array('popular_posts', 'register'));
class popular_posts {
function control(){
echo '';
}
function widget($args){
extract( $args );
echo $before_widget;
 ?>
<ul>
<?php
global $post;
$pargs = array( 'numberposts' => 10,'orderby'=> 'comment_count', );
$myposts = get_posts( $pargs );
foreach( $myposts as $post ) :  setup_postdata($post); ?>
<li><a href="<?php the_permalink(); ?>"><p><?php the_title(); ?></p> </a> </li>
<?php endforeach; ?>
</ul>
<?php
echo $after_widget;
}
function register(){
register_sidebar_widget('Popular posts', array('popular_posts', 'widget'));
register_widget_control('Popular posts', array('popular_posts', 'control'));
}
}


$popular_post = get_template_directory() . '/widget/popular_post/wordpress-popular-posts.php';
if(!$data['popular_post'])      {
		include $popular_post;  }








?>