<div class="left-sidebar">

 <?php if ( ! dynamic_sidebar( 'left-sidebar' ) ) : ?>   
 
 <?php  endif; ?>
 
 

</div>