<div id="footer">
	<p>2012. Untitled. All rights reserved. Photos by <a href="http://fotogrph.com/">Fotogrph</a>. Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
<!-- end #footer -->

<?php wp_footer();  ?>
</body>
</html>