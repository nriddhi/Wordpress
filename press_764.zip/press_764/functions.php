<?php


// add menu support and fallback menu if menu doesn't exist
	add_action('init', 'wpj_register_menu');
	function wpj_register_menu() {
	if (function_exists('register_nav_menu')) 
	{
	register_nav_menu( 'wpj-main-menu', __( 'MainMenu', 'Riddhi' ) );
	}    }
	function wpj_default_menu() {
	echo '<ul id="tiny">';
	if ('page' != get_option('show_on_front')) 
	{    echo '<li><a href="'. home_url() . '/">Home</a></li>';
	}       wp_list_pages('title_li=');
		echo '</ul>';
	}

	


//theme support

add_theme_support( 'post-thumbnails', array( 'post', 'slider') );
add_image_size( 'slider-image', 640, 600, true );


//Custom post slider

	function create_post_type() {
               
	         register_post_type( 'slider',
	 array(
	'labels' => array(
	 'name' => __( 'slider' ),
	 'singular_name' => __( 'slider' ),
	 'add_new' => __( 'Add New' ),
	 'add_new_item' => __( 'Add New slider' ),
	 'edit_item' => __( 'Edit slider' ),
	 'new_item' => __( 'New slider' ),
	 'view_item' => __( 'View slider' ),
	 'not_found' => __( 'Sorry, we couldn\'t find the Testimonial you are looking for.' )
				),
				
	'public' => true,
    'publicly_queryable' => false,
	'exclude_from_search' => true,
	'menu_position' => 14,
	'has_archive' => false,
	'hierarchical' => false, 
	'capability_type' => 'page',
    'rewrite' => array( 'slug' => 'slider' ),
	'supports' => array( 'title', 'thumbnail' )
			)
		);
	}

add_action( 'init', 'create_post_type' );


//post image support

add_theme_support( 'post-thumbnails', array( 'post', 'post-image') );
add_image_size( 'post-image', 172, 172, true );

// Register Widget

function press_widgets_init() {
     
	 register_sidebar( array(
        'name'          => __( 'categories', 'twentythirteen' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Appears in the footer section of the site.', 'twentythirteen' ),
        'before_widget' => '<div class="widget-area">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'comments', 'twentythirteen' ),
        'id'            => 'sidebar-2',
        'description'   => __( 'Appears in the footer section of the site.', 'twentythirteen' ),
        'before_widget' => '<div class="widget-area">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
	
	
	register_sidebar( array(
        'name'          => __( 'socials', 'twentythirteen' ),
        'id'            => 'sidebar-3',
        'description'   => __( 'Appears in the footer section of the site.', 'twentythirteen' ),
        'before_widget' => '<div class="widget-area">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'pages', 'twentythirteen' ),
        'id'            => 'sidebar-4',
        'description'   => __( 'Appears in the footer section of the site.', 'twentythirteen' ),
        'before_widget' => '<div class="widget-area">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
	
	
	
	
	
	
	
}

add_action( 'widgets_init', 'press_widgets_init' );






?>