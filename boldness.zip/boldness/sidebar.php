	<div id="sidebar-bg">
			<div id="sidebar">
				<ul>
					<li>
						<h2>Introduction</h2>
                     <?php if ( ! dynamic_sidebar( 'Main Widget' ) ) : ?>   
                    
					<?php  endif; ?>					
					
					</li>
					
					<li>
						<ul>
							<?php if ( ! dynamic_sidebar( 'Second Widget' ) ) : ?>   
                    
					        <?php  endif; ?>
						</ul>
					</li>
					
					<li>
						<ul>
							<?php if ( ! dynamic_sidebar( 'third Widget' ) ) : ?>   
                    
					        <?php  endif; ?>
							
						</ul>
					</li>
				</ul>
			</div>
		</div>