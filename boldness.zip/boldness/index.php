<?php get_header(); ?>
	<!-- end #menu -->
	<div id="page">
		<div id="content">
			
 <?php get_template_part('slider') ?>
			
			<?php if(have_posts()) : ?>
            <?php while(have_posts())  : the_post(); ?>

			
			<div class="post">
				<h2 class="title"><a href="<?php the_permalink(); ?>"><?php  the_title();   ?>  </a></h2>
				<p class="meta">Posted by <a href="#"><?php the_author_posts_link()?></a> on <?php the_time('M d, Y') ?>
					&nbsp;&bull;&nbsp; <a href="#" class="comments">// <?php comments_number( 'no responses', 'one response', '% responses' ); ?></a> &nbsp;&bull;&nbsp; <a href="<?php the_permalink(); ?>" class="permalink">Full article</a></p>
				<div class="entry">
				
				<?php the_content();  ?>
					
				</div>
			</div>
			
			    <?php endwhile; ?>
                <?php else : ?>
                <?php get_template_part('404') ?>
                <?php endif; ?>	

			
			
			
			<div style="clear: both;">&nbsp;</div>
		</div>
		<!-- end #content -->
	
	<?php get_sidebar(); ?>
	
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>

<?php get_footer(); ?>
