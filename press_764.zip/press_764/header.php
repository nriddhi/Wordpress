<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php bloginfo('name'); ?></title>
<meta name="keywords" content="press blog theme, free css template, blogger, templatemo" />
<meta name="description" content="Press Theme - Free Blog Template for everyone" />
<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />

<link href="<?php echo get_template_directory_uri(); ?>/css/svwp_style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery-1.3.2.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.slideViewerPro.1.0.js" type="text/javascript"></script>

<!-- Optional plugins  -->
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.timers.js" type="text/javascript"></script>

<?php wp_head(); ?>
</head>
<body>

<div id="templatemo_header_wrapper">
	<div id="templatemo_header">
    
    	<div id="site_title">
            <h1><a href="<?php bloginfo('home'); ?>" target="_parent"><img src="<?php echo get_template_directory_uri(); ?>/images/templatemo_logo.png" alt="logo" /><span>Free Blog Theme in HTML/CSS</span></a></h1>
      	</div> <!-- end of site_title -->
        
        <div id="templatemo_menu">
            <?php	
         if (function_exists('wp_nav_menu'))    	{	
         wp_nav_menu(array(
         'theme_location' => 'wpj-main-menu', 
         'menu_id' => 'nav', 
          'fallback_cb' => 'wpj_default_menu')); 
         }  else     {  wpj_default_menu();  }	
         
		 ?>
   	
        </div> <!-- end of templatemo_menu -->
    
    </div>
</div> <!-- end of templatemo_header -->