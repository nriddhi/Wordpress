<div id="templatmeo_sidebar">
        
        	<div class="content_box_wrapper">
                <div class="content_box">
                
				<?php get_search_form( ); ?>
                
                </div>
            </div>
            
            <div class="content_box_wrapper">
                <div class="content_box">
            
			 <?php if ( ! dynamic_sidebar( 'categories' ) ) : ?>   
                   <?php  endif; ?>

			
			
				</div>
			</div>
            
            <div class="content_box_wrapper">
                <div class="content_box">
            
			
			 <?php if ( ! dynamic_sidebar( 'comments' ) ) : ?>   
                   <?php  endif; ?>

                   
        		</div>
			</div>
            
        </div>