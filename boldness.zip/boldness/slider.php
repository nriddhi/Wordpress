<div id="slider">
				<div class="viewer">
					<div class="reel">
 

                 <?php if(!is_paged()) { ?>
				
				<?php
					  $args = array( 'post_type' => 'slider', 'posts_per_page' => 4 );
					  $loop = new WP_Query( $args );
				?>  
			
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

			   <div class="slide">
					
			   <?php the_post_thumbnail('slider-image', array('class' => 'post-thumb')); ?>
								
                </div>						
						
				<?php endwhile; ?>
				<?php wp_reset_query(); ?>
				<?php } ?>			

					</div>
				</div>
			</div>
			<script type="text/javascript">
				$('#slider').slidertron({
					viewerSelector: '.viewer',
					reelSelector: '.viewer .reel',
					slidesSelector: '.viewer .reel .slide',
					advanceDelay: 3000,
					speed: 'slow'
				});
			</script>