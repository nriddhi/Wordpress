<?php if(have_posts()) : ?>
 <?php while(have_posts())  : the_post(); ?>

<div class="blog-post">


       <?php
			if ( is_single() ) :
				the_title( '<h2 class="post-title">', '</h2>' );
			else :
				the_title( '<h2 class="post-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
			endif;
		?>
  

<div class="blog-post-para">

<p> <?php echo get_excerpt(475); ?>
</p>


 
 
 </div>
 
<div class="post-category">
<p>
<?php the_author()?> | <?php the_time('M d, Y') ?> | 
<a class="more" href="<?php echo get_page_link(); ?>"> MORE...</a>

</p>

</div>


</div>

<?php endwhile; ?>
<?php else : ?>
    <?php get_template_part('404') ?>
<?php endif; ?>	

<div class="nav-previous"><?php next_posts_link( __( ' Next---<span class="meta-nav">&gt;</span>') ); ?></div><div class="nav-next"><?php previous_posts_link( __( '<span class="meta-nav">&lt;</span>---Previous ') ); ?></div>
