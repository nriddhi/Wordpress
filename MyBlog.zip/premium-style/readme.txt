################### About ##########################################################################################

Theme Name	: Premium Style
Theme URI	: http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/
Author		: Gopi Ramasamy
Author URI	: http://www.gopiplus.com
Live Demo	: http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/

###################  Features of this theme  ########################################################################

1.  Free theme
2.  Highly customizable
3.  100% Responsive
4.  Valid XHTML5 + CSS
5.  Firefox, IE8+, Chrome and Safari compatible
6.  WP 3.6+ compatible
7.  Blog style structure
8.  Social Icon settings
9.  Option to add Google Analytic
10. Option to enable/disable Author Info Box
11. Breadcrumbs links
12. Free 24x5 email support

###################  FAQ  ##########################################################################################

Q1. How do I install the theme onto my WordPress blog?

Upload via Dashboard

1. Download theme (premium-style.zip) from download location.
2. Log in to your WordPress Administration Panel.
3. Select the Appearance panel, then Themes.
4. Select Install Themes.
5. Click the Upload button to upload the file that you have previously downloaded to your machine.
6. Activate the theme.

Upload via FTP

1. Download theme (premium-style.zip) from download location.
2. Unzip the premium-style.zip file, you may see all theme files are located in the the-professional folder.
3. Using an FTP client to access your host web server.
4. Upload the premium-style folder to the /wp-content/themes/ directory on your host server.
5. Go to the themes page, from the available themes section, activate the theme.

Q2. How to setup Thumbnails and Featured image for post?

Q3. How do I install the theme onto my WordPress blog?

Q4. How to setup Thumbnails and Featured image for post?

Q5. How to Disable and Enable home page slider?

Q6. How to configure Top Social link in the theme?

Q7. How to add favicon?

Q8. How to add Google Analytic in the website?

Answers: 
http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/

############################## LIVE DEMO ##########################################################################

http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/

############################## DOCUMENTATION ######################################################################

http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/

############################## VIDEO TUTORIAL #####################################################################

http://www.gopiplus.com/work/2013/11/11/premium-style-wordpress-theme/