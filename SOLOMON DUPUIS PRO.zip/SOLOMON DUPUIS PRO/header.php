<!DOCTYPE">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>

<link  href="<?php bloginfo('stylesheet_url'); ?> " type="text/css" rel="stylesheet" />

<link href="<?php echo get_template_directory_uri(); ?>/font/font.css" type="text/css" rel="stylesheet"  />



<?php  wp_head();   ?>
</head>



<body data-spy="scroll" data-target=".top-menu" data-offset="75">



<div id="masthead" class="top-menu">

<div class="container">

<div class="top-left-side">

<div class="logo">
<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>  ">

<img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="" />

</a>
</div>

</div>


<div class="top-right-side">


<div class="main-menu">

<?php
				if (function_exists('wp_nav_menu')) {
wp_nav_menu(array('theme_location' => 'wpj-main-menu',   
 'menu_id' => 'nav', 'fallback_cb' => 'wpj_default_menu'));   }
				else     {  wpj_default_menu();}
				?>



</ul>

</div>


<div class="search">
<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div><input type="text" size="18" value="<?php echo wp_specialchars($s, 1); ?>" name="s" id="s" />
<input type="submit" id="searchsubmit" value="Search" class="btn" />
</div>
</form>

</div>

</div>

</div>

</div>
